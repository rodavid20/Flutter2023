import 'package:flutter/material.dart';
import 'screen/home_app.dart';

void main() => runApp(HomeApp());
